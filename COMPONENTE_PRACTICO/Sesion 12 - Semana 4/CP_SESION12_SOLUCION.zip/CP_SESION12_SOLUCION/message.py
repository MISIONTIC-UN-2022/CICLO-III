mensajes =[{'usuario':'Persona123', 'asunto':'Hola', 'mensaje':'Hola, un saludo especial'},
{'usuario':'Usuario987', 'asunto':'Chao', 'mensaje':'Chao, nos vemos luego'}]
